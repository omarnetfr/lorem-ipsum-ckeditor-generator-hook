CKEDITOR.plugins.setLang( 'loremipsum', 'fr', {
	title: 'Lorem Ipsum Generator',
	toolbar: 'Lorem Ipsum Generator',
	paragraph: 'Paraghraphe',
	sentence: 'Phrase',
	paragraphs: 'Paraghraphes',
	sentences: 'Phrases'
} );